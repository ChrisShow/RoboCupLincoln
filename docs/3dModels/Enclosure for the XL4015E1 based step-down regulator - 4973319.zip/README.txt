Enclosure for the XL4015E1 based step-down regulator by glassy on Thingiverse: https://www.thingiverse.com/thing:4973319

Summary:
This is a compact enclosure for the XL4015E1 based step-down regulator (mine was branded "Tenstar Robot" https://www.aliexpress.com/item/32711173698.html?spm=a2g0s.9042311.0.0.27424c4dQXcFNM )If you found my design useful or inspiring and would like to buy me a cup of espresso you are welcome to tip me:https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&amp;hosted_button_id=U25V96GZNVL3N&amp;source=url