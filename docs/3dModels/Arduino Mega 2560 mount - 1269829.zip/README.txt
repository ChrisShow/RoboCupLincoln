Arduino Mega 2560 mount by srtigger on Thingiverse: https://www.thingiverse.com/thing:1269829

Summary:
You can put your Arduino Mega 2560 (v3) into this protective shield securing the board using the stifts (without glue/ without screws).3mm holes on every 10mm on both side.