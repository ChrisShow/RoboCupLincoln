TCS230 color sensor cap by lightfingers on Thingiverse: https://www.thingiverse.com/thing:2219462

Summary:
I noticed that my color sensor had some trouble with ambient light.A different version of this sensor (TCS3200), comes with a cap/lens included.So I made one for this version. Definitely improves the output of this sensor in different ambient light levels.It fits quite snugly around the leds.