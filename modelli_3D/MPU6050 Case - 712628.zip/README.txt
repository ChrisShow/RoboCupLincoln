MPU6050 Case by JBalsells on Thingiverse: https://www.thingiverse.com/thing:712628

Summary:
Box of protection of MPU6050 sensor 